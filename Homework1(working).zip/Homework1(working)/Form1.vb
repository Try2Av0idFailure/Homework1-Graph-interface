﻿Public Class frmNumbers
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnOne.Click
        lblFrench.Text = "un"
    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnTwo.Click
        lblFrench.Text = "deux"
    End Sub
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles btnThree.Click
        lblFrench.Text = "trois"
    End Sub
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles btnFour.Click
        lblFrench.Text = "quatre"
    End Sub
    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles btnFive.Click
        lblFrench.Text = "cinq"
    End Sub
    Private Sub ButtonExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Application.Exit()
    End Sub
End Class
